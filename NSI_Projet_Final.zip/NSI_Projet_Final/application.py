# -*- coding: utf-8 -*-

# @Date      : 2022-05-23 11:17:48
# @Auteur(s) : Souleimane El Qodsi et Anas Chati
# @Titre     : NSI - Projet Final - Application Flask

from datetime import datetime
from flask import Flask, render_template, url_for
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///site.db"
db = SQLAlchemy(app)

# https://whimsical.com/lyautey-shop-mcd-3bLi6bzb93CefXrf4kKQBf


class Categories(db.Model):
    idCategorie = db.Column(db.Integer, primary_key=True)
    nom = db.Column(db.String(700), nullable=False)
    populaire = db.Column(db.Boolean, default=False)


class Produits(db.Model):
    idProduit = db.Column(db.Integer, primary_key=True)
    titre = db.Column(db.String(200), nullable=False)
    prix = db.Column(db.Integer, nullable=False)
    marque = db.Column(db.String(125), nullable=False)
    details = db.Column(db.String(1500))
    image1 = db.Column(db.String(1500))
    image2 = db.Column(db.String(1500))
    image3 = db.Column(db.String(1500))
    note = db.Column(db.Integer)
    date_publication = db.Column(db.DateTime, default=datetime.utcnow())
    #idCategorie = db.Column(db.Integer, db.ForeignKey(
   #     "Categories.idCategorie"), nullable=False)


@app.route("/")
@app.route("/header")
def home():
    return render_template("header.html")


def html():
    to_html = []
    produits = Produits.query.all()
    to_html.extend(produit.__dict__ for produit in produits)
    return to_html


@app.route("/page-produits")
def page_produits():
    return render_template("page-produits.html", produits=html())


@app.route("/produit")
def produit():
    return render_template("produit.html")


if __name__ == "__main__":
    app.run(debug=True)
